#include "MicroBit.h"

#ifndef MICROBIT_CODAL
#ifdef CODAL_CONFIG_H
#define MICROBIT_CODAL 1
#else
#define MICROBIT_CODAL 0
#endif
#endif

MicroBit uBit;

void togglePixel( int x, int y);

uint64_t time0 = 0;
uint64_t time1 = 0;
uint64_t timeD = 0;

uint64_t second = 1000000;

uint16_t event_id = 60000;
uint16_t event_value = 0;
CODAL_TIMESTAMP event_period = 10000;

void sendDifference()
{
    time1 = system_timer_current_time_us();
    timeD = time1 - time0;

    int us  = (int) (timeD % second);
    int sec = (int) (timeD / second);
    int min = sec / 60;
    sec = sec % 60;

    ManagedString sm( min);
    ManagedString ss( sec);
    ManagedString su( us);
    uBit.serial.send( sm + ":" + ss + "." + su + "\n");
}


void onEvent(MicroBitEvent e)
{
    uBit.io.P0.setDigitalValue(1);
    uBit.serial.send( "onEvent     \n");
    sendDifference();
    uBit.io.P0.setDigitalValue(0);
    uBit.power.deepSleep( event_period - 500, uBit.systemTimer);
    uBit.serial.send( "after sleep \n");
    sendDifference();
    togglePixel( 4, 4);
    uBit.sleep(100);
    togglePixel( 4, 4);
}


void onEventNoSleep(MicroBitEvent e)
{
    uBit.io.P0.setDigitalValue(1);
    uBit.serial.send( "onEventNoSleep \n");
    sendDifference();
    uBit.io.P0.setDigitalValue(0);
    togglePixel( 4, 4);
    uBit.sleep(100);
    togglePixel( 4, 4);
}


void onButtonA(MicroBitEvent e)
{
    uBit.serial.send( "onButtonA   \n");
    uBit.io.P0.setDigitalValue(0);
    uBit.messageBus.listen( event_id, event_value, onEvent);
    sendDifference();
    time0 = time1;
    system_timer_event_every( event_period, event_id, event_value);
}


void onButtonB(MicroBitEvent e)
{
    uBit.serial.send( "onButtonB   \n");
    uBit.io.P0.setDigitalValue(0);
    uBit.messageBus.listen( event_id, event_value, onEventNoSleep);
    sendDifference();
    time0 = time1;
    system_timer_event_every( event_period, event_id, event_value);
}


void togglePixel( int x, int y)
{
    uBit.display.image.setPixelValue( x, y, uBit.display.image.getPixelValue( x, y) ? 0 : 255);
}


void forever()
{
    while (true)
    {
        togglePixel( 0, 0);
        uBit.sleep(1000);
    }
}


int  main()
{
    uBit.init();

    uBit.messageBus.listen( MICROBIT_ID_BUTTON_A,  MICROBIT_BUTTON_EVT_CLICK, onButtonA);
    uBit.messageBus.listen( MICROBIT_ID_BUTTON_B,  MICROBIT_BUTTON_EVT_CLICK, onButtonB);

    create_fiber( forever);

    release_fiber();
}