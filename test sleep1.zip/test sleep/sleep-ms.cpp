//10s periodic timer event sets P0 high briefly
//P1 wakes
//P2 is collecting analogue

//To choose sleep mode, Reset then
//A for deepSleep
//B for deepSleep(milliseconds)
//AB for deepSleep(P1)
//P1 for no deep sleep

#include "MicroBit.h"

#ifndef MICROBIT_CODAL
#ifdef CODAL_CONFIG_H
#define MICROBIT_CODAL 1
#else
#define MICROBIT_CODAL 0
#endif
#endif

MicroBit uBit;

void togglePixel( int x, int y);

uint64_t time0 = 0;
uint64_t time1 = 0;
uint64_t timeD = 0;

uint64_t second = 1000000;

uint16_t timer_id = 60000;
uint16_t timer_value = 0;
CODAL_TIMESTAMP timer_period = 10000; //ms

int p2_analogue;
int light_level;

int sleepMode = 0;


void doSleep()
{
    switch ( sleepMode)
    {
        case 0: uBit.power.deepSleep(); break;
        case 1: uBit.power.deepSleep( timer_period - 1000); break;
        case 2: uBit.power.deepSleep( uBit.io.P1); break;
        case 3: uBit.sleep( timer_period + 1000); break;
    }
}


void sendTime()
{
    time1 = system_timer_current_time_us();
    timeD = time1 - time0;

    int us  = (int) (timeD % second);
    int sec = (int) (timeD / second);
    int min = sec / 60;
    sec = sec % 60;

    ManagedString sm( min);
    ManagedString ss( sec);
    ManagedString su( us);
    ManagedString msg = "(time " + sm + ":" + ss + "." + su + ")";
    DMESG( msg.toCharArray());
}

////////////////////////////////////////////////////////////////

void onTimer(MicroBitEvent e)
{
    DMESGN( "ONTIMER enter ");
    sendTime();

    p2_analogue = uBit.io.P2.getAnalogValue();

    uBit.io.P0.setDigitalValue(1);
    togglePixel( 3, 0);
    uBit.sleep(100);
    togglePixel( 3, 0);
    uBit.io.P0.setDigitalValue(0);

    DMESG( "onTimer sleep %d", sleepMode);
    doSleep();

    DMESGN( "onTimer after sleep ");
    sendTime();
}


void onEvent(MicroBitEvent e)
{
    DMESGN( "ONEVENT %d, %d ", (int) e.source, (int) e.value);
    sendTime();

    togglePixel( 4, 0);
    uBit.sleep(100);
    togglePixel( 4, 0);

    DMESGN( "onEvent %d, %d EXIT ", (int) e.source, (int) e.value);
    sendTime();
}


void test_forever()
{
    DMESGN( "test_forever ");
    sendTime();
    time0 = time1;

    uBit.radio.datagram.send( ManagedString("onstart"));
    uBit.io.P0.setDigitalValue(0);
    p2_analogue = uBit.io.P2.getAnalogValue();
    light_level = uBit.display.readLightLevel();

    uBit.io.P1.setPull(PullMode::Down);
    uBit.io.P1.eventOn(DEVICE_PIN_EVENT_ON_EDGE);

    uBit.messageBus.listen( MICROBIT_ID_BUTTON_A,  MICROBIT_BUTTON_EVT_CLICK, onEvent);
    uBit.messageBus.listen( MICROBIT_ID_BUTTON_B,  MICROBIT_BUTTON_EVT_CLICK, onEvent);
    uBit.messageBus.listen( MICROBIT_ID_IO_P1,     MICROBIT_EVT_ANY,          onEvent);
    uBit.messageBus.listen( MICROBIT_ID_IO_P5,     MICROBIT_EVT_ANY,          onEvent);
    uBit.messageBus.listen( MICROBIT_ID_IO_P11,    MICROBIT_EVT_ANY,          onEvent);
    uBit.messageBus.listen( timer_id, timer_value, onTimer);

    uBit.io.P1.wakeOnActive(1);
    uBit.io.P2.wakeOnActive(1);
    //uBit.io.P5.wakeOnActive(1);
    //uBit.io.P11.wakeOnActive(1);

    DMESG( "P1  wake %d", uBit.io.P1.getWakeOnActive());
    DMESG( "P2  wake %d", uBit.io.P2.getWakeOnActive());
    DMESG( "P5  wake %d", uBit.io.P5.getWakeOnActive());
    DMESG( "P11 wake %d", uBit.io.P11.getWakeOnActive());

    system_timer_event_every( timer_period, timer_id, timer_value, CODAL_TIMER_EVENT_FLAGS_WAKEUP);

    while (true)
    {
        p2_analogue = uBit.io.P2.getAnalogValue();
        light_level = uBit.display.readLightLevel();
        DMESG( "p2_analogue %d light_level %d", p2_analogue, light_level);
        uBit.sleep(2000);
    }
}

////////////////////////////////////////////////////////////////

void onButtonA(MicroBitEvent e);
void onButtonB(MicroBitEvent e);
void onButtonAB(MicroBitEvent e);
void onPin(MicroBitEvent e);

void start_test( int mode)
{
    DMESG( "start_test %d", mode);
    uBit.messageBus.ignore( MICROBIT_ID_BUTTON_A,  MICROBIT_BUTTON_EVT_CLICK, onButtonA);
    uBit.messageBus.ignore( MICROBIT_ID_BUTTON_B,  MICROBIT_BUTTON_EVT_CLICK, onButtonB);
    uBit.messageBus.ignore( MICROBIT_ID_BUTTON_AB, MICROBIT_BUTTON_EVT_CLICK, onButtonAB);
    uBit.messageBus.ignore( MICROBIT_ID_IO_P1,     MICROBIT_EVT_ANY,          onPin);
    sleepMode = mode;
    create_fiber( test_forever);
}

void onButtonA(MicroBitEvent e)
{
    DMESG( "onButtonA");
    start_test( 0);
}


void onButtonB(MicroBitEvent e)
{
    DMESG( "onButtonB");
    start_test( 1);
}


void onButtonAB(MicroBitEvent e)
{
    DMESG( "onButtonAB");
    start_test( 2);
}

void onPin(MicroBitEvent e)
{
    DMESG( "onPin %d, %d ", (int) e.source, (int) e.value);
    start_test( 3);
}

////////////////////////////////////////////////////////////////

void togglePixel( int x, int y)
{
    uBit.display.image.setPixelValue( x, y, uBit.display.image.getPixelValue( x, y) ? 0 : 255);
}


void forever()
{
    while (true)
    {
        togglePixel( 0, 0);
        uBit.sleep(1000);
    }
}


int  main()
{
    uBit.init();

    create_fiber( forever);

    uBit.io.P1.setPull(PullMode::Down);
    uBit.io.P1.eventOn(DEVICE_PIN_EVENT_ON_EDGE);

    uBit.messageBus.listen( MICROBIT_ID_IO_P1,     MICROBIT_EVT_ANY,          onPin);

    uBit.messageBus.listen( MICROBIT_ID_BUTTON_A,  MICROBIT_BUTTON_EVT_CLICK, onButtonA);
    uBit.messageBus.listen( MICROBIT_ID_BUTTON_B,  MICROBIT_BUTTON_EVT_CLICK, onButtonB);
    uBit.messageBus.listen( MICROBIT_ID_BUTTON_AB, MICROBIT_BUTTON_EVT_CLICK, onButtonAB);

    release_fiber();
}